# Implement Client Script & UI Policy (Incident)

Naan Mudhalvan ServiceNow project demo.

## Project
This project demonstrates Client Scripts and UI Policies on an Incident form.

## Demo
Open `index.html` in a browser, or publish the repository using GitHub Pages.

## Implemented behavior
1. UI Policy-style behavior: High urgency makes Impact mandatory.
2. onChange Client Script behavior: Resolved state displays and requires Resolution Notes.
3. onSubmit Client Script behavior: Form validation prevents incomplete submission.
4. Responsive Incident form UI.

## ServiceNow mapping
- Milestone 1: Create UI Policy on Incident
- Milestone 2: Create UI Policy Action – Urgency
- Milestone 3: Create onChange Client Script
- Milestone 4: Create onSubmit Client Script
- Milestone 5: Create onCellEdit Client Script
- Milestone 6: Testing the Configuration

Note: The public demo is a browser simulation. The actual ServiceNow configuration should be demonstrated in a ServiceNow Personal Developer Instance (PDI).
